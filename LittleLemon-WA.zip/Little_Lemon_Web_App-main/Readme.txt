API endpoints
=============
/restaurant/
/restaurant/booking/
/restaurant/booking/tables/
/restaurant/menu/
/auth/users/  #use this to create a user
/auth/token/login/  #use this to login

#after login a token is generated.
#use the generated token with the API endpoint below
/restaurant/api-token-auth/
